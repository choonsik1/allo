# EVA on Allo → SystemC → Catapult — findings and problems
Prepared 2026-08-19. Catapult Ultra Synthesis **2024.2/1130128**, library
**nangate-45nm_beh** (Nangate Open Cell 45 nm, typical, 1.10 V, 25 °C), clock 2.0 ns,
`-IO_MODE super -SPECULATE true`. **HLS only — no place & route, no power.**

---

## TL;DR

1. **Emitter bug (blocking).** `#pragma hls_pipeline_init_interval` is emitted *above*
   `#ifdef __SYNTHESIS__`, so Catapult **silently discards it** for 9 of 17 loops — the PE
   node and all 8 drivers. No warning is issued. This hid a **5.75× throughput improvement**.
2. **Elastic pipelines; our v16 cannot.** With the pragma placed correctly, the elastic PE
   schedules at **II=4: 23 → 4 cycles/iteration, −5.3 % area, and it meets 2.0 ns** (the
   unscheduled build misses it). v16 fails at **every** II tried.
3. **Why v16 cannot** — not a tool limit: its node **drives the same port more than once per
   iteration** (`v24.rdy.write#1` *and* `write#2`; `v8.vld.write#6`). A port takes one drive
   per cycle, so no II is satisfiable. Caused by v16's always-fire + non-blocking
   (`try_put`/`try_get`) style: **28 non-blocking ops/iteration vs elastic's 4**.
4. **II=2 is the true recurrence floor and Catapult reaches it** — the same II Vitis reaches
   without the `distance=2` dependence waiver. We are not behind Vitis; we simply never
   ported that waiver (or the `bind_op` operator latencies).

## Problem 1 — pragma placement (emitter)

Emitted (synthesis branch — pragma separated from its loop by a preprocessor line and a statement):
```cpp
    #pragma hls_pipeline_init_interval 1
#ifdef __SYNTHESIS__
    done.write(true);
    while (1) {                       // ← Catapult never associates the pragma with this
#else
    l_steady: for (int t = 0; t < 1290; t += 1) {
#endif
```
Working case (a collector — pragma directly above its loop header):
```cpp
    #pragma hls_pipeline_init_interval 1
    l_S_it_0_it: for (int it = 0; it < 1290; it++) {
```
**Evidence:** `evidence/01_pragma_detected_before_fix.txt` (8 of 17 acknowledged via CIN-203)
vs `evidence/02_pragma_detected_after_fix.txt` (17 of 17). The 8 that worked are exactly the
collectors, which have no `#ifdef` between pragma and loop.
**Fix:** emit the pragma **inside each `#ifdef` branch, immediately above the loop header**
(SystemC `emitAffineFor` override — the base emitter cannot know about the branch split).
**Note:** after fixing, `II=1` fails *loudly* (SCHD-30) where it previously failed silently.
A sensible default II should ship with the fix.

## Problem 2 — v16 drives the same port repeatedly (design)

`SCHD-30 "could not schedule even with unlimited resources"`, **identical histogram at
II=2, 4 and 8** (20 iomode + 2 chained-control) — i.e. not II-scaled:
```
I/O_WRITE SIGNAL "v24.rdy" @ ASSIGN "v24.rdy.write#1:asn(v24.rdy)"
I/O_WRITE SIGNAL "v24.rdy" @ ASSIGN "v24.rdy.write#2:asn(v24.rdy)"
I/O_WRITE SIGNAL  "v8.vld" @ ASSIGN  "v8.vld.write#6:asn(v8.vld)"
```
`v21..v24` are the four systolic inputs. Source pattern:
```python
if hold_cnt[2] < 2:
    gw, kw = sys_e[i, j].try_get()     # drives rdy on the taken path AND the default path
```
| | Push | Pop | PushNB | PopNB | total/iter |
|---|---|---|---|---|---|
| v16 | 44 | 20 | 22 | 6 | **92** |
| elastic | 16 | 16 | 2 | 2 | **36** |

**Fix direction:** compute the value, then drive each port **once** per iteration. Elastic
already does this — it guards *blocking* ops with `full()`/`empty()` instead of using
non-blocking ops under conditionals.

## Finding — elastic II sweep (1 PE, 2.0 ns)
| II | node cycles/iter | AREA | max delay | |
|---|---|---|---|---|
| unscheduled | 23 | 54,526.7 | 2.0831 | ✗ misses 2.0 ns |
| 2 | 2 | 64,475.2 (+18.2 %) | **5.0109** | ✗ path blows out |
| **4** | **4** | **51,636.5 (−5.3 %)** | **1.9980** | ✅ **optimum** |
| 8 | 8 | 51,521.2 (−5.5 %) | 1.9984 | ✓ |
| 16 | 16 | 51,340.8 (−5.8 %) | 1.9827 | ✓ |

**II=4 dominates unscheduled on all three axes** and is the first config to meet 2.0 ns.
Recipe (from `$MGC_HOME/shared/examples/connections/Adder/ccs.tcl`) — applied **after
`go assembly`**, the stall mode is required:
```tcl
directive set /top/node_0_0/run/while -PIPELINE_INIT_INTERVAL 4
directive set /top/node_0_0/run/while -PIPELINE_STALL_MODE flush
```

## Claims we RETRACTED (recorded so they are not repeated)
| retracted | corrected |
|---|---|
| "pipeline pragmas do nothing" | they were being **dropped**; elastic gets 5.75× at II=4 |
| "the loop is handshake-limited" | not supported; the limit is port drives / iomode placement |
| "blocking `Pop()`/`Push()` ⇒ no fixed II" | **false** — II is over the *stall-free* schedule; the handshake stalls at runtime. Counterexamples: our whvcrouter at Init 2, MatchLib WHVC router at Init 1 |
| "`-IO_MODE super` blocks pipelining" | false — the whole successful sweep ran with it set |
| "use unscheduled" | superseded: **II=4 for elastic**; v16 needs the port fix first |

## Status of the other numbers (all **unscheduled** — provisional)
Area (2.0 ns, same emitter): 1 PE — elastic 54,527 · **v16 56,955** · v3.0 74,872 ·
skid 111,965 · int16-skid 108,968. 8×8 — **v16 1,650,541** · v3.0 1,889,687 · elastic
2,011,692. Note elastic is **−4.3 % vs v16 at 1 PE but +21.9 % at 8×8**.
Correctness (new emitter): v16 **640 outputs 0 mismatches csim AND RTL cosim**; elastic
**80 outputs 0 mismatches on the golden vectors** (csim) + MMM ladder 1×1…8×8.
⚠️ **Every RTL cycle count in the project was measured unscheduled** and is stale if
pipelining is adopted.

## Also blocked
`int16_elastic` will not compile: `emitBitcast` hardcodes `half` for 16-bit bitcasts, so an
int16 element type yields `half v; v.set_data(ac_int<16,true>(...))` →
`CRD-312/CRD-413: no suitable conversion`. int16 **skid** builds, so it is specific to
elastic's `.bitcast()` usage. See `evidence/05_int16_bitcast_errors.txt`.

## Reproduce
```bash
# elastic at II=4 (the win)
CHIP=eva_fp16_elastic MESH=1 NSTEP=215 CLK=2.0 PRJ=<dir> python scripts/csyn_probe.py
#   then in <dir>/run.tcl, after `go assembly`, add the two directives above and re-run:
#   catapult -shell -f run.tcl
# v16 (fails at every II) — same recipe, CHIP=eva_v16
```
