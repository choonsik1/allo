#!/bin/bash
# v16 node-loop II sweep, same vendor recipe that gave elastic II=4 (5.75x thr, -5.3% area,
# meets 2.0 ns). v16's node is heavier (ops 1909 vs 1695, thr 33 vs 23 unscheduled), so its
# optimum may differ. EVERY RTL cycle count we have was measured UNSCHEDULED, so if v16
# pipelines too, the whole throughput table (and the v16-vs-elastic verdict) is stale.
PY=/home/zsm9/miniconda3/envs/allo/bin/python
export MGC_HOME=/opt/siemens/catapult/2024.2/Mgc_home
O=/scratch/zsm9/eva_runs/pipe_v16; mkdir -p $O; : > $O/STATUS
cd /home/zsm9/final_eva_systemc
for II in 2 4 8; do
  P=$O/prj_$II; rm -rf $P
  CHIP=eva_v16 DTYPE=fp16 MESH=1 NSTEP=215 CLK=2.0 PRJ=$P SCHED=0 \
    $PY - <<'PYE' >/dev/null 2>&1
import os, sys, importlib
os.environ.setdefault("MGC_HOME","/opt/siemens/catapult/2024.2/Mgc_home")
MGC=os.environ["MGC_HOME"]; os.environ["PATH"]=f"{MGC}/bin:"+os.environ.get("PATH","")
os.environ.setdefault("SYSTEMC_HOME", f"{MGC}/shared")
R="/home/zsm9/final_eva_systemc"
sys.path.insert(0,"/home/zsm9/allo_sup"); sys.path.insert(0,R+"/chip")
for d in ("designs/v16_VERIFIED_credfree_uniform",): sys.path.insert(0,R+"/"+d)
e=importlib.import_module("eva_v16"); sys.modules["eva"]=e
import allo.dataflow as df
from allo.ir.types import float16
e.M=e.N=1; e.NSTEP=e.LANELEN=215
df.build(e.get_eva_top(float16), target="systemc", mode="csyn",
         project=os.environ["PRJ"], configs={"clock_period":2.0})
PYE
  # v16's steady loop is `while` under __SYNTHESIS__, same shape as elastic's
  python3 - "$P/run.tcl" "$II" <<'PYE'
import sys
p,ii=sys.argv[1],sys.argv[2]; s=open(p).read()
s=s.replace("go assembly\ngo extract", f"""go assembly
directive set /top/node_0_0/run/while -PIPELINE_INIT_INTERVAL {ii}
directive set /top/node_0_0/run/while -PIPELINE_STALL_MODE flush
go architect
go extract""")
open(p,"w").write(s)
PYE
  (cd $P && $MGC_HOME/bin/catapult -shell -f run.tcl > $O/ii$II.log 2>&1); rc=$?
  R=$(find $P -name rtl.rpt 2>/dev/null | head -1)
  PIPE=$(grep -oE "'/top/node_0_0/run/[A-Za-z0-9_]+' is pipelined with initiation interval [0-9]+" $O/ii$II.log | grep -oE "[0-9]+$" | head -1)
  if [ -n "$R" ]; then
    A=$(grep -m1 'TOTAL AREA' $R | grep -oE '[0-9]+\.[0-9]+' | head -1)
    N=$(grep -m1 -E '^  /top/node_0_0/run' $R | sed 's/  */ /g' | awk '{print "lat="$3" thr="$4}')
    D=$(awk '/Critical Path/{f=1} f&&/Max Delay:/{print $3; exit}' $R)
    echo "v16 II=$II rc=$rc PIPELINED[${PIPE:-no}] AREA=$A $N MaxDelay=$D  [unsched: AREA=56954.778 thr=33 D=1.9987470]" >> $O/STATUS
  else
    C=$(grep -A40 "SCHD-30" $O/ii$II.log | grep -oE "(iomode|chained control|chained data|recurrence|memory|resource) constraint" | sort | uniq -c | tr '\n' ' ')
    echo "v16 II=$II rc=$rc FAILED  constraints: ${C:-none}" >> $O/STATUS
  fi
done
echo "PIPE_V16 DONE $(date +%T)" >> $O/STATUS
