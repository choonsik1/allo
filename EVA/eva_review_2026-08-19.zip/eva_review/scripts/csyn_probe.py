#!/usr/bin/env python3
# Minimal csyn probe: does a chip variant SYNTHESIZE at all?
#
# Purpose is the error list, not the area. v13/v15 mix blocking put() and try_put() on
# the same systolic channel (node prime loop + pre-loop emission + in-loop try_put),
# which has previously produced CIN-150 "Multiple writers". 1x1 answers that in minutes;
# the mesh size does not change whether the error fires.
#
# NOTE: csyn takes mod() with NO arguments (allo/backend/hls.py asserts this) -- the
# run_*_systemc.py drivers pass arrays and trip the assert before Catapult ever runs.
#
#   CHIP=eva_v15 MESH=1 PRJ=/scratch/... python scripts/csyn_probe.py
import os, sys, glob, importlib
import numpy as np

os.environ.setdefault("OMP_NUM_THREADS", "8")
os.environ.setdefault("MGC_HOME", "/opt/siemens/catapult/2024.2/Mgc_home")
MGC = os.environ["MGC_HOME"]
os.environ["PATH"] = f"{MGC}/bin:" + os.environ.get("PATH", "")
os.environ.setdefault("SYSTEMC_HOME", f"{MGC}/shared")
os.environ["LD_LIBRARY_PATH"] = f"{MGC}/lib:{MGC}/shared/lib:" + os.environ.get("LD_LIBRARY_PATH", "")
os.environ.setdefault("ALLO_COSIM_SYNTH_TIMEOUT", "36000")

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, "/home/zsm9/allo_sup"); sys.path.insert(0, os.path.join(ROOT, "chip"))
for p in sorted(sum([glob.glob(os.path.join(ROOT, _d, "v[0-9]*"))
                      for _d in ("designs", "tools", "deadends")], [])):
    if os.path.isdir(p):
        sys.path.append(p)
sys.path.append(os.path.join(ROOT, "designs", "from_verification"))

CHIP = os.environ.get("CHIP", "eva_v15")
MESH = int(os.environ.get("MESH", "1"))
NSTEP = int(os.environ.get("NSTEP", "215"))
PRJ = os.environ["PRJ"]
# CLK: clock period in ns. Catapult BAKES THE PERIOD INTO THE SCHEDULE (how many ops it
# packs per cycle), so this is not a pure constraint -- it is the timing/area knob.
# Use it to sweep the frequency FLOOR: v16 closes 2.0 ns at 8x8 with only +0.0013 ns of
# slack, so 500 MHz is a lower bound, not the answer.
CLK = float(os.environ.get("CLK", "2.0"))

e = importlib.import_module(CHIP); sys.modules["eva"] = e
import allo.dataflow as df
from allo.ir.types import float16, int16
# DTYPE selects the datatype-generic chips' element type (int16 variants exist
# in designs/from_verification but were never synthesized).
_TY = {'fp16': float16, 'int16': int16}[os.environ.get('DTYPE', 'fp16')]

e.M = e.N = MESH
e.NSTEP = e.LANELEN = NSTEP
if hasattr(e, "RUN_BUDGET"):          # elastic: fixed trip count = max(RUN_BUDGET, 6*LANELEN)
    e.RUN_BUDGET = int(os.environ.get("BUDGET", str(6 * NSTEP)))
print(f"=== CSYN PROBE  CHIP={CHIP}  {MESH}x{MESH}  NSTEP={NSTEP}  CLK={CLK} ns  DTYPE={os.environ.get('DTYPE','fp16')} ===", flush=True)
os.system(f"rm -rf {PRJ}")
# The verification chips expose get_eva_top_elastic(); ours expose get_eva_top().
_top = (e.get_eva_top_elastic(_TY) if hasattr(e, "get_eva_top_elastic")
        else e.get_eva_top(_TY))
# SCHED replicates the chip's OWN Allo schedule (the verification chips apply this in
# their __main__ for the Vitis flow; our Catapult builds normally skip it):
#   0 = none (default, and the right choice for our chips — II=1 buys ZERO RTL cycles
#       while costing +30 % area / +33 % critical path at 8x8)
#   1 = s.pipeline on every node + IO loop        (elastic __main__, pipeline part)
#   2 = 1 + s.partition on the 23 per-node buffers (elastic __main__, full)
_SCHED = int(os.environ.get("SCHED", "0"))
if _SCHED:
    _IT = "it" if hasattr(e, "get_eva_top_elastic") else "t"   # elastic names its loop `it`
    _s = df.customize(_top)
    for _i in range(MESH):
        for _j in range(MESH):
            _s.pipeline(f"node_{_i}_{_j}:{_IT}")
            if _SCHED >= 2:
                for _b in ("irf drf drf_full hold_v hold_cnt ig_p ig_v oh_p oh_v txp_d txp_v "
                           "resq cmpq sb_v sb_dst sb_cmp sb_rtr sb_inj sb_dir sb_id sb_rvld "
                           "sb_ix sb_long").split():
                    _s.partition(f"node_{_i}_{_j}:{_b}")
    for _io in ("drv_w drv_e drv_n drv_s col_w col_e col_n col_s rdrv_w rdrv_e rdrv_n "
                "rdrv_s rclc_w rclc_e rclc_n rclc_s").split():
        _s.pipeline(f"{_io}_0:{_IT}")
    mod = _s.build(target="systemc", mode="csyn", project=PRJ,
                   configs={"clock_period": CLK})
else:
    mod = df.build(_top, target="systemc", mode="csyn", project=PRJ,
                   configs={"clock_period": CLK})
print(f"emitted -> {PRJ}; running Catapult ...", flush=True)
mod()                      # csyn: NO arguments
print("=== CSYN RETURNED (no exception) ===")
