#!/bin/bash
# II=1 is unschedulable for the node loop (SCHD-30, even with unlimited resources).
# But the loop currently costs ~23 cycles/iteration, so ANY achievable II would be a win.
# Sweep II upward with the vendor recipe (TCL directive after `go assembly` + STALL_MODE
# flush), node loop only. Baseline: unscheduled AREA 54526.684, node lat=1 thr=23.
PY=/home/zsm9/miniconda3/envs/allo/bin/python
export MGC_HOME=/opt/siemens/catapult/2024.2/Mgc_home
O=/scratch/zsm9/eva_runs/pipe_ii; mkdir -p $O; : > $O/STATUS
cd /home/zsm9/final_eva_systemc
for II in 2 4 8 16; do
  P=$O/prj_$II; rm -rf $P
  PRJ=$P $PY - <<'PYE' >/dev/null 2>&1
import os, sys, importlib
os.environ.setdefault("MGC_HOME","/opt/siemens/catapult/2024.2/Mgc_home")
MGC=os.environ["MGC_HOME"]; os.environ["PATH"]=f"{MGC}/bin:"+os.environ.get("PATH","")
os.environ.setdefault("SYSTEMC_HOME", f"{MGC}/shared")
R="/home/zsm9/final_eva_systemc"
sys.path.insert(0,"/home/zsm9/allo_sup"); sys.path.insert(0,R+"/chip")
sys.path.insert(0,R+"/designs/from_verification")
e=importlib.import_module("eva_fp16_elastic"); sys.modules["eva"]=e
import allo.dataflow as df
from allo.ir.types import float16
e.M=e.N=1; e.NSTEP=e.LANELEN=215; e.RUN_BUDGET=6*215
df.build(e.get_eva_top_elastic(float16), target="systemc", mode="csyn",
         project=os.environ["PRJ"], configs={"clock_period":2.0})
PYE
  python3 - "$P/run.tcl" "$II" <<'PYE'
import sys
p,ii=sys.argv[1],sys.argv[2]; s=open(p).read()
s=s.replace("go assembly\ngo extract", f"""go assembly
directive set /top/node_0_0/run/while -PIPELINE_INIT_INTERVAL {ii}
directive set /top/node_0_0/run/while -PIPELINE_STALL_MODE flush
go architect
go extract""")
open(p,"w").write(s)
PYE
  (cd $P && $MGC_HOME/bin/catapult -shell -f run.tcl > $O/ii$II.log 2>&1)
  rc=$?
  R=$(find $P -name rtl.rpt 2>/dev/null | head -1)
  PIPE=$(grep -oE "Loop '/top/node_0_0/run/[A-Za-z0-9_]+' is pipelined with initiation interval [0-9]+" $O/ii$II.log | grep -oE "interval [0-9]+" | head -1)
  if [ -n "$R" ]; then
    A=$(grep -m1 'TOTAL AREA' $R | grep -oE '[0-9]+\.[0-9]+' | head -1)
    N=$(grep -m1 -E '^  /top/node_0_0/run' $R | sed 's/  */ /g' | awk '{print "lat="$3" thr="$4}')
    D=$(awk '/Critical Path/{f=1} f&&/Max Delay:/{print $3; exit}' $R)
    echo "II=$II rc=$rc PIPELINED[$PIPE] AREA=$A $N MaxDelay=$D   [base: AREA=54526.684 lat=1 thr=23 D=2.0830950]" >> $O/STATUS
  else
    echo "II=$II rc=$rc FAILED: $(grep -m1 -oE 'could not schedule partition[^-]*' $O/ii$II.log)" >> $O/STATUS
  fi
done
echo "PIPE_II DONE $(date +%T)" >> $O/STATUS
