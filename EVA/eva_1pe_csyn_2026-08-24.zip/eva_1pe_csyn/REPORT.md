# EVA 1 PE Catapult synthesis — final numbers, and how to read the II

2026-08-24. Six chips, 1 PE, Catapult Ultra Synthesis 2024.2, Nangate 45 nm
(`nangate-45nm_beh`, typical 1.10 V / 25 °C), 2.0 ns clock, `-IO_MODE super`,
`-SPECULATE true`. Post-assignment area, **pre-layout — no logic synthesis, no P&R**.

## Results — node loop pipelined at II=1

| chip | Freq (MHz) | Loop depth | II | Area | Flops | Logic |
|---|---|---|---|---|---|---|
| fp16 elastic  | 253 | 3 | 1 | 73,061  | 3,891 | 29,310 |
| int16 elastic | 250 | 2 | 1 | 68,480  | 3,890 | 26,209 |
| fp16 skid     | 487 | 3 | 1 | 152,759 | 9,281 | 38,238 |
| int16 skid    | 459 | 2 | 1 | 152,460 | 9,246 | 39,384 |
| fp16 skid rbuf2  | 487 | 3 | 1 | 152,759 | 9,281 | 38,238 |
| int16 skid rbuf2 | 459 | 2 | 1 | 152,460 | 9,246 | 39,384 |

All six scheduled cleanly (`SCHD-43`, no `SCHD-30`) with `PIPELINE_STALL_MODE flush`.
Re-run from scratch on 2026-08-24; every value reproduced the earlier archive to three
decimals. `Flops` = summed register bits from the `rtl.rpt` register table (Catapult
reports no placed-cell count).

## Unscheduled baseline, same chips

| chip | Freq (MHz) | Loop depth | II | Area | Flops | Logic |
|---|---|---|---|---|---|---|
| fp16 elastic  | 480 | 7 | — | 55,374  | 3,602 | 13,222 |
| int16 elastic | 500 | 8 | — | 51,999  | 3,576 | 11,582 |
| fp16 skid     | 471 | 9 | — | 145,545 | 8,899 | 33,379 |
| int16 skid    | 535 | 9 | — | 142,626 | 8,868 | 32,054 |

Pipelining costs elastic heavily (480 → 253 MHz, +32 % area) and skid barely at all
(471 → 487 MHz, +5 %).

## ⭐ Where the II actually is — and four columns that are NOT it

**The II is the `Init` column** of the Loops table in `cycle.rpt`, confirmed against the
`SCHD-43` log line at three points (`evidence/01_Init_is_the_II.txt`):

| requested | `Init` | SCHD-43 |
|---|---|---|
| 1 | 1 | "initiation interval 1 and flushing" |
| 2 | 2 | "initiation interval 2" |
| 4 | 4 | "initiation interval 4 and no flushing" |

Four columns that look like the II and are not. Each of these misled this investigation
at least once:

| column | what it really is |
|---|---|
| `C-Steps` (Loops table) | schedule **depth** — the figure comparable to Vitis's per-iteration latency (3–6) |
| `Total Cycles` (Loops table) | latency **including nested loops**; = C-Steps + Σ nested (7+4·4=23 unscheduled) |
| `Throughput Cycles` (Loop Execution Profile) | Catapult's **static estimate of stalled throughput** (16 here). NOT measured — these runs contain no simulation (`run.tcl` is analyze→compile→assembly→architect→extract; report header says `Current state: schedule`) |
| `II` (Processes table) | **process**-level pipelining — 0 for all 19 processes (`evidence/02`) |

Read the II from `Init`, and confirm with:
`zcat reports/catapult.log.gz | grep SCHD-43`

## Blocking vs non-blocking

Neither machine uses non-blocking primitives — **zero** `try_put`/`try_get` anywhere.
Both emit ordinary blocking `Push`/`Pop`. The difference is guarding
(`evidence/03_blocking_vs_guarded.txt`):

| chip | put | get | try_put | try_get | `full()` | `empty()` |
|---|---|---|---|---|---|---|
| fp16 elastic | 16 | 18 | 0 | 0 | **16** | **16** |
| fp16 skid    | 88 | 34 | 0 | 0 | **0**  | **0**  |

Elastic checks the FIFO before every call, so the blocking op is reached only when it
cannot block — "guarded blocking (data-driven)". Skid is unguarded and genuinely blocks.
Catapult still builds a wait controller per blocking call regardless of the guard
(44 × `SCHD-46` in the elastic node loop), which is why its static throughput estimate is
pessimistic.

## rbuf2 is a measured no-op in this flow

`helpers/skid_inject_full_rbuf2.py` adds `#pragma HLS array_partition variable=rbuf
complete dim=2` to the **Vitis** kernel after emission. Catapult ignores Vitis HLS pragmas
and the emitted SystemC contains zero `array_partition` lines, so the transfer was done via
the Allo equivalent `s.partition(node:rbuf, Complete, dim=2)`.

**Result: byte-identical to plain skid in both schedules, confirmed three times.**
Catapult infers no memories at 1 PE (`MEM/ROM = 0`), so `rbuf` is already registers with
every element independently addressable — "complete partition" was the starting state.
Catapult has no `array_partition` directive at all; the nearest lever is `MAP_TO_MODULE`,
which forces an array *out* of a RAM. **Do not present the rbuf2 rows as a distinct design.**
Their value is the P&R data at `verification/{fp16,int16}_skid/pnr_rbuf2_1x1/`, which
Catapult cannot produce.

## Scope

- 1 PE only. No 8×8, **no cosim, no RTL simulation of any kind.**
- Throughput is not measured anywhere here. `Init` is the scheduled II; actual rate under
  mesh backpressure requires a cosim.
- Separately open: elastic drops the last output(s) per lane on the deep golden vectors
  (see `eva_tail_truncation_2026-08-24.zip`). Correctness only — synthesis numbers unaffected.

## Contents

    chips/     the 4 canonical Aug-19 sources + the rbuf2 injector + CHECKSUMS.txt
    evidence/  01 Init==II (3-point) · 02 Processes-II is 0 · 03 blocking vs guarded
    results/   per chip × schedule: SUMMARY.txt, node_loop_rows.txt, area_scores.txt,
               SCHD-43.txt, run.tcl
