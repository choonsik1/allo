import re,sys,os
src=open(sys.argv[1]).read(); LAT="2"; NODEP=os.environ.get("NODEP","0")=="1"
# NOTE 2026-08-16: rbuf/rbcnt/rcred/scred RESTORED. Removing them (to dodge the rbuf carried-dep
# that pushes int16 to II=2) was a TRADE-OFF, not a clean win: fp16 rebuilt WITHOUT the rbuf
# partition produced ALL-ZERO output (functionally broken) — the partition is functionally required.
# For int16 II=1 use the prebuilt int16skid_csynth (Aug-14) instead of removing partitions here.
RF=["cmpq","drf","drf_full","rbuf","rbcnt","rcred","scred","hold_cnt","hold_v","ig_p","ig_v","irf","oh_p","oh_v","resq",
    "sb_cmp","sb_dir","sb_dst","sb_id","sb_inj","sb_ix","sb_long","sb_rtr","sb_rvld","sb_v","txp_d","txp_v"]
n={"part":0,"dep":0,"bind":0,"pipe":0}
fn={"node":0,"drvcol":0}   # functions that MUST each receive exactly one pipeline pragma
parts=re.split(r"(?m)^(void [A-Za-z_]\w*\()",src); out=[parts[0]]
for kk in range(1,len(parts),2):
    sig=parts[kk]; body=parts[kk+1] if kk+1<len(parts) else ""
    # 2026-08-18 ROUTER DRIVERS/COLLECTORS ADDED: rdrv_/rclc_ were SKIPPED here, leaving their main
    # loop (l_S_t_2_t7x / l_S_t_1_t7x) UNPIPELINED -> iteration latency 81 (8 serial shift loops) ->
    # ~81*prime cyc/out. They have the same shift structure as drv_/col_ (which pipeline to iter-lat 4).
    if sig.startswith("void node_") or sig.startswith("void drv_") or sig.startswith("void col_") \
       or sig.startswith("void rdrv_") or sig.startswith("void rclc_"):
        fn["node" if sig.startswith("void node_") else "drvcol"]+=1
        is_node=sig.startswith("void node_")
        prag="\n  #pragma HLS pipeline II=1"
        if is_node and not NODEP:
            for base in ["resq","cmpq"]:
                m=re.search(r"\b(%s\d*)\["%base,body)
                if m: prag+="\n  #pragma HLS dependence variable=%s type=inter direction=RAW distance=2 dependent=true"%m.group(1); n["dep"]+=1
        for base in RF:
            m=re.search(r"\b(%s\d*)\["%base,body)
            if m:
                prag+="\n  #pragma HLS array_partition variable=%s complete dim=1"%m.group(1); n["part"]+=1
                if base in ("hold_v","rbuf"): prag+="\n  #pragma HLS array_partition variable=%s complete dim=2"%m.group(1); n["part"]+=1
        # anchor: the labeled main RUN_BUDGET loop  ( l_S_it_..._it...: for (int it... = 0; ... { )
        body,c=re.subn(r"(?m)^(\s*l_S_(?:it|t)[a-z0-9_]*: for \(int (?:it|t)[a-z0-9_]* = 0;[^\n]*\{[^\n]*)$",
                       lambda m,p=prag:m.group(1)+p, body, count=1)
        n["pipe"]+=c
        # 2026-08-17 DRIVER/COLLECTOR ARG-ARRAY PARTITION (matches the native scheduler; the missing
        # bit that left drv_ at II=7 and col_ at II=4). The per-lane data args (din,vd -> drv; dout ->
        # col) are renamed to vNNNN in codegen, so match by STRUCTURE: an arg array vNNNN[M][LANELEN]
        # with 2nd dim > 1st dim (the [M][8]=pcfg is skipped). Insert at FUNCTION scope (after ') {').
        if not is_node:
            arghead = body.split("{",1)[0]
            argprag = ""
            for am in re.finditer(r"\b(v\d+)\[(\d+)\]\[(\d+)\]", arghead):
                if int(am.group(3)) > int(am.group(2)):
                    argprag += "\n  #pragma HLS array_partition variable=%s complete dim=1"%am.group(1); n["part"]+=1
            if argprag:
                body,ac = re.subn(r"(\)\s*\{)", lambda m,a=argprag:m.group(1)+a, body, count=1)
                assert ac==1, "drv/col arg-partition anchor ') {' not found"
    out+=[sig,body]
src="".join(out)
for pat,op,impl in [(r"(half (v\d+) = v\d+ \* v\d+;)","hmul","maxdsp"),(r"(half (v\d+) = v\d+ \+ v\d+;)","hadd","fabric")]:
    src,c=re.subn(pat,lambda m,o=op,i=impl:m.group(1)+"\n#pragma HLS bind_op variable=%s op=%s impl=%s latency=%s"%(m.group(2),o,i,LAT),src); n["bind"]+=c
# STRUCTURAL FAIL-LOUDLY (2026-08-18): the old assert derived its expectation from the SAME name
# filter (node_/drv_/col_) that had the bug — a check that agrees with its own blind spot, so it
# never flagged the unpipelined rdrv_/rclc_ router loops. Replace it with a LOOP-SHAPE query that is
# independent of the matcher: find every MAIN timestep loop in the emitted kernel (label l_S_(it|t)…
# with an (it|t)-indexed counter — this excludes the l_S_sft_ shift subloops, whose counter is sft…)
# and assert each one is immediately followed by a pipeline pragma. A new function family nobody
# named (drivers once, router drivers once) can no longer slip through: if it has a timestep loop and
# didn't get a pragma, this fails.
ANCHOR = re.compile(r'(?m)^(\s*l_S_(?:it|t)[a-z0-9_]*: for \(int (?:it|t)[a-z0-9_]* = 0;[^\n]*\{[^\n]*)$')
unpiped = [m.group(1).strip()[:55] for m in ANCHOR.finditer(src) if 'HLS pipeline' not in src[m.end():m.end()+160]]
_main = sum(1 for _ in ANCHOR.finditer(src))
assert not unpiped, (
    f"STRUCTURAL FAIL-LOUDLY: {len(unpiped)} of {_main} main timestep loops received NO pipeline "
    f"pragma (loop-shape query, name-independent). Refusing to emit a silently-underpipelined "
    f"kernel. First offenders: {unpiped[:4]}")
# secondary (informational): the name-based count that used to be the whole check
_exp = fn["node"] + fn["drvcol"]
open(sys.argv[2],"w").write(src); print(f"full inject: {n}  (STRUCTURAL: all {_main} main timestep loops pipelined; name-based node {fn['node']} + drv/col {fn['drvcol']} = {_exp})")
