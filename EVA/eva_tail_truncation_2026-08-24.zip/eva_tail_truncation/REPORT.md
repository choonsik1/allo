# ELASTIC drops the last output(s) of every lane — 2026-08-24

## Summary

On the **deep** golden vectors, the elastic EVA chip emits **N−1 (or N−k) of N** expected
outputs on every lane. Every value it does emit is **bit-exact**; only the tail is missing.

| vectors | expected / lane | got | missing |
|---|---|---|---|
| `fp16_elastic/fft_ap`   | 40 | 39 | last 1, all 8 lanes |
| `int16_elastic/fft_i16` | 40 | 39 | last 1, all 8 lanes |
| `fp16_elastic/cordic_cr_ap` | 20 (even rows) / 40 (odd) | 19 / 37 | last 1 / last 3 |

**This is csim only.** No 8×8 cosim has been run — see "What has NOT been done".

## Chips under test

The **Aug-19 revisions** (`chips/`, checksums in `chips/CHECKSUMS.txt`), byte-identical to
`/work/shared/users/zsm9/verification/<chip>/eva_<chip>.py`:

    eva_fp16_elastic.py   421770fe0d47899ab2ee3396289172f0   Aug 19 12:05
    eva_int16_elastic.py  5ca37c5a14b46676dc405f45c99833b0   Aug 19 12:05

Emitter: `allo_sup` `EmitSystemC.cpp` Aug 20 13:17; `_allo…so` Aug 20 13:18 (verified current).

## Ruled out — with evidence

| hypothesis | verdict | evidence |
|---|---|---|
| int16-specific | **NO** — fp16 identical at matched depth | `04_fp16_fft_ap_ALSO_39of40.txt` |
| introduced by the Aug-19 chip revision | **NO** — the Aug-15 file truncates identically | `07_AUG15_chip_SAME_truncation.txt` |
| drain time / `RUN_BUDGET` | **NO** — 12k/16k/24k/**60k (5×)** byte-identical | `03_…`, `06_budget_60k_5x_IDENTICAL.txt` |
| collector starvation | **NO** — `col_*` loop on `BUDGET`, same as the node; `LANELEN` (2000) only caps the write index vs ~40 outputs. They idled 60k iterations waiting for a value that never arrived | source, `chips/eva_fp16_elastic.py` `def col_e` |

**=> The final value never reaches the collector. The node stops producing it.**
Working hypothesis (UNVERIFIED): a last-instruction-retire issue — the program (VPC=112)
ends and the final result sits in a hold awaiting a grant whose operand never arrives.

## Why this was not caught earlier

The **canonical** vectors (the six plain workload names, the documented set) carry
**VGMAX 2 — two outputs per lane**. A missing-tail bug is structurally invisible at depth 2.
The previously-reported elastic result ("6/6 workloads, 80 outputs, 0 mismatches") is real
but is ~2 outputs/lane and does **not** establish that elastic emits its final output.

`02_fp16_shallow_PASS_vs_int16.txt` shows this directly: the same chip PASSES 8/8 lanes on
the 2-deep `fft` and fails on the 40-deep `fft_ap`.

## The deep vectors are a certified oracle

From `vectors_doc/README_provenance.md`: the generator was **certified bit-exact against the
captured RTL golden** before generating, and every emitted header was **round-trip verified
(all 10 OK)**. The README states: *"If a chip's ALU differs from this contract the mismatch
is the finding, not the vector."*

- cordic **20 (even rows) / 40 (odd rows) is BY DESIGN** — not an anomaly.
- Expected counts must come from `vectors_doc/EXPECTED_COUNTS.json`, *"never from a
  constant"* — counts are data-dependent by construction.

## Harness bugs found and fixed en route (all in `harness/run_golden_vec_systemc.py`)

1. **fp16-only.** `float16` was hardcoded in 4 places (top-level type arg, both array
   dtypes, the bit-compare). The int16 chips could never have been verified through it.
   Now derives the type from `#define VECTOR_DTYPE` in the header.
2. **`int16_elastic` plain workload names are STALE fp16 vectors.** The real int16 set is
   the `_i16` suffix; `int16_skid` uses the PLAIN names. Mixing them gives 16/16 mismatches
   that look exactly like a dead chip. The driver now aborts on a chip/vector dtype mismatch.
3. **The `!= 0` filter dropped INTERIOR zeros**, misaligning the compare — harmless for
   fp16, wrong for int16 where 0 is a common output. Now compares position-wise to the last
   nonzero.
4. **Two `.h` at different depths per directory** (`fft/fft.h` VGMAX 2 *and*
   `fft/fft_aperiodic.h` VGMAX 40). The `<WL>/<WL>.h` path rule always picks the shallow one.

## What has NOT been done

- **No 8×8 cosim. No RTL simulation at all.** Every result here is csim; the 20 archived
  synthesis runs are all `csyn_1x1`.
- The Aug-19 v3.0 / elastic 8×8 cosims referenced in the project README as "running" were
  lost when `/scratch` was reused. Nothing has replaced them.
- Consequently **no chip is currently RTL-verified at 8×8 on the current emitter.**

## Scope

Correctness only. The 1 PE synthesis numbers in `results/` are unaffected — csyn never runs
the vector path.

## Reproduce

```bash
cd /home/zsm9/final_eva_systemc
PY=/home/zsm9/miniconda3/envs/allo/bin/python

# fails: 39/40 per lane
CHIP=eva_fp16_elastic VEC=fp16_elastic WL=fft_ap MODE=csim PRJ=/tmp/deep \
  $PY scripts/run_golden_vec_systemc.py

# "passes": same chip, 2-deep vectors — too shallow to see it
CHIP=eva_fp16_elastic VEC=fp16_elastic WL=fft MODE=csim PRJ=/tmp/shallow \
  $PY scripts/run_golden_vec_systemc.py
```

## Contents

    chips/        the 4 Aug-19 chip sources + the Aug-15 fp16_elastic used for the A/B
    harness/      the golden-vector driver, csyn probe, report/archive helpers, tb_eva.cpp
    vectors_doc/  vector README, provenance README, EXPECTED_COUNTS.json, gen_int16.py
    evidence/     the 7 decisive run logs, named for what each one proves
    results/      SUMMARY.txt for the 1 PE csyn runs (area/timing — unaffected)
