// tb_eva.cpp — ONE golden-replay testbench for all four EVA chips.
// Two compile-time flags select the chip:
//   -DHAS_PRIME   runtime-prime chips (skid): adds the leading prime_cfg[VM][VN]
//                 port + the DUT_PRIME/DUT_MACHINE_ID stimulus contract.
//   -DINT16       int16 lane datatype (default = half / fp16).
// So:  fp16_elastic = (none) ; int16_elastic = -DINT16 ;
//      fp16_skid = -DHAS_PRIME ; int16_skid = -DHAS_PRIME -DINT16.
// The vector header (-DVECHDR="…h") supplies VM/VN/VL/VOUT_IDX/VGMAX/VECNAME,
// IN0..3 / IV0..3 / RIN0..3 / EOUT1 / EOUT3, and (skid) PRIMECFG. The compare is
// a windowed search for each row's golden subsequence on the active output edge
// (VOUT_IDX==1 → out_e east, else out_s south) — identical for every chip.
#include <cstdio>
#include <cstring>
#include <cstdint>
#include "hls_half.h"
#include VECHDR

#ifdef INT16
typedef int16_t DT;
#else
typedef half DT;
#endif

// datatype stimulus contract (2026-08-18): an int16 vector on a non-INT16 DUT (or vice versa)
// silently mis-reads the 16-bit words. Fail at compile time instead.
#if defined(VECTOR_DTYPE_INT16) && !defined(INT16)
# error "STIMULUS CONTRACT: VECTOR_DTYPE_INT16 vector but DUT not built with -DINT16"
#endif
#if !defined(VECTOR_DTYPE_INT16) && defined(INT16)
# error "STIMULUS CONTRACT: fp16 vector but DUT built with -DINT16 — wrong datatype"
#endif

// skid stimulus contract: a wrong machine/prime pairing must not build
#if defined(HAS_PRIME)
# if defined(DUT_PRIME) && defined(VECTOR_PRIME) && (VECTOR_PRIME != DUT_PRIME)
#  error "STIMULUS CONTRACT: VECTOR_PRIME != DUT_PRIME — regenerate vectors at the DUT prime"
# endif
# if defined(DUT_MACHINE_ID) && defined(VECTOR_MACHINE_ID) && (VECTOR_MACHINE_ID != DUT_MACHINE_ID)
#  error "STIMULUS CONTRACT: VECTOR_MACHINE_ID != DUT_MACHINE_ID — wrong machine's vectors"
# endif
#endif

void top(
#ifdef HAS_PRIME
         int32_t prime_cfg[VM][VN],
#endif
         DT in_w[VM][VL], int32_t iv_w[VM][VL],
         DT in_e[VM][VL], int32_t iv_e[VM][VL],
         DT in_n[VN][VL], int32_t iv_n[VN][VL],
         DT in_s[VN][VL], int32_t iv_s[VN][VL],
         DT out_w[VM][VL], DT out_e[VM][VL],
         DT out_n[VN][VL], DT out_s[VN][VL],
#ifdef DBG_PROBE
         int32_t dbg[VM][VN][64],   // Allo emits dbg at arg pos 13 (after out_s, before rin_w)
#endif
         int32_t rin_w[VM][VL], int32_t rin_e[VM][VL],
         int32_t rin_n[VN][VL], int32_t rin_s[VN][VL],
         int32_t rout_w[VM][VL], int32_t rout_e[VM][VL],
         int32_t rout_n[VN][VL], int32_t rout_s[VN][VL]
         );

static void fill(DT *d, const unsigned short *b, int n) { for (int i = 0; i < n; i++) memcpy(&d[i], &b[i], 2); }
static inline unsigned short hb(const DT *h) { unsigned short u; memcpy(&u, h, 2); return u; }

int main() {
    static DT      in_w[VM][VL], in_e[VM][VL], in_n[VN][VL], in_s[VN][VL];
    static DT      out_w[VM][VL], out_e[VM][VL], out_n[VN][VL], out_s[VN][VL];
    static int32_t iv_w[VM][VL], iv_e[VM][VL], iv_n[VN][VL], iv_s[VN][VL];
    static int32_t rin_w[VM][VL], rin_e[VM][VL], rin_n[VN][VL], rin_s[VN][VL];
    static int32_t rout_w[VM][VL], rout_e[VM][VL], rout_n[VN][VL], rout_s[VN][VL];
#ifdef DBG_PROBE
    static int32_t dbg_buf[VM][VN][64];   // DEBUG PROBE readout buffer (rc_mon taps its RTL write port)
#endif
#ifdef HAS_PRIME
    static int32_t prime_cfg[VM][VN];
    memcpy(prime_cfg, PRIMECFG, sizeof prime_cfg);
    printf("[eva] %s driven with prime_cfg=%d\n", VECNAME, prime_cfg[0][0]);
#else
    printf("[eva] %s (elastic — no prime)\n", VECNAME);
#endif

    fill(&in_w[0][0], &IN0[0][0], VM * VL); fill(&in_e[0][0], &IN1[0][0], VM * VL);
    fill(&in_n[0][0], &IN2[0][0], VN * VL); fill(&in_s[0][0], &IN3[0][0], VN * VL);
    memcpy(iv_w, IV0, sizeof iv_w); memcpy(iv_e, IV1, sizeof iv_e);
    memcpy(iv_n, IV2, sizeof iv_n); memcpy(iv_s, IV3, sizeof iv_s);
    memcpy(rin_w, RIN0, sizeof rin_w); memcpy(rin_e, RIN1, sizeof rin_e);
    memcpy(rin_n, RIN2, sizeof rin_n); memcpy(rin_s, RIN3, sizeof rin_s);

    top(
#ifdef HAS_PRIME
        prime_cfg,
#endif
        in_w, iv_w, in_e, iv_e, in_n, iv_n, in_s, iv_s,
        out_w, out_e, out_n, out_s,
#ifdef DBG_PROBE
        dbg_buf,
#endif
        rin_w, rin_e, rin_n, rin_s,
        rout_w, rout_e, rout_n, rout_s
        );

    DT (*out)[VL] = (VOUT_IDX == 1) ? out_e : out_s;
    const unsigned short (*gold)[VL] = (const unsigned short(*)[VL])
        ((VOUT_IDX == 1) ? &EOUT1[0][0] : &EOUT3[0][0]);
    const char *edge = (VOUT_IDX == 1) ? "out_e(east)" : "out_s(south)";

    printf("golden replay (%s) — %s vs golden (%d vals/row)\n", VECNAME, edge, VGMAX);
    int rows_ok = 0;
    for (int k = 0; k < VN; k++) {
        unsigned short g[VGMAX]; int ng = 0;
        for (int t = 0; t < VGMAX; t++) { g[t] = gold[k][t]; if (g[t]) ng = t + 1; }
        if (ng == 0) { printf("  row %d: (no golden)\n", k); rows_ok++; continue; }
        int found = -1;
        for (int s = 0; s + ng <= VL; s++) {
            int ok = 1;
            for (int t = 0; t < ng; t++) if (hb(&out[k][s + t]) != g[t]) { ok = 0; break; }
            if (ok) { found = s; break; }
        }
        char seen[80]; int p = 0, cnt = 0;
        for (int t = 0; t < VL && cnt < 6; t++) { unsigned short v = hb(&out[k][t]); if (v) { p += snprintf(seen + p, sizeof(seen) - p, "%04x ", v); cnt++; } }
        printf("  row %d: %s golden", k, found >= 0 ? "OK " : "x  ");
        for (int t = 0; t < ng; t++) printf(" %04x", g[t]);
        printf(found >= 0 ? "  @slot %d  (nz: %s)\n" : "  NOT found  (nz: %s)\n", found >= 0 ? found : 0, seen);
        if (found >= 0) rows_ok++;
    }
    int clean = (rows_ok == VN);
    printf("%s: cosim %s (%d/%d rows bit-exact vs golden)\n",
           clean ? "PASS" : "FAIL", VECNAME, rows_ok, VN);
    return 0;
}
