#!/usr/bin/env python3
"""
EVA int16 (and aperiodic fp16 cordic) golden generator.
  * ISA-level, data-driven event simulator of the decoded 8x8 program network
    (grant iff operands available) — CERTIFIED bit-exact vs the captured fp16 RTL
    golden for mmm(analytic), fft(20 batches interpreter) and all 4 cordic variants.
  * int16 arithmetic = wraparound two's complement (Allo int16 ops); SUB is TRUE
    subtraction (the E3 fix), GEQ/LT produce +1 / -1 integer results
    (int16_skid/e2fix `res = 1 / -1`).
  * Emits ELASTIC-format headers (dense slots, no bubbles) with contract #defines
    (VECTOR_DTYPE / VECTOR_MACHINE_ID). Skid format is produced by the credit-path
    builder from these — see README emitted alongside.
"""
import re, sys, os, json
import numpy as np
from collections import defaultdict

SRC = os.path.dirname(os.path.abspath(__file__)) + "/eva_fft_cordic_vectors"
OUT = os.path.dirname(os.path.abspath(__file__)) + "/int16_vectors"
os.makedirs(OUT, exist_ok=True)

u2h = lambda u: np.frombuffer(np.uint16(int(u) & 0xFFFF).tobytes(), np.float16)[0]
h2u = lambda h: int(np.frombuffer(np.float16(h).tobytes(), np.uint16)[0])
def s16(u):
    u &= 0xFFFF
    return u - 0x10000 if u & 0x8000 else u
def w16(v):  # wraparound to u16
    return int(v) & 0xFFFF

# ---------- arithmetic packs ----------
FP16 = dict(
    ADD=lambda a, b: h2u(np.float16(u2h(a) + u2h(b))),
    SUB=lambda a, b: h2u(np.float16(u2h(a) + np.float16(-u2h(b)))),   # sign-flip = ISA float SUB
    MUL=lambda a, b: h2u(np.float16(u2h(a) * u2h(b))),
    GEQ=lambda a, b: 0x3c00 if u2h(a) >= u2h(b) else 0xbc00,
    LT =lambda a, b: 0x3c00 if u2h(a) <  u2h(b) else 0xbc00,
    dtype="fp16")
INT16 = dict(
    ADD=lambda a, b: w16(s16(a) + s16(b)),
    SUB=lambda a, b: w16(s16(a) - s16(b)),
    MUL=lambda a, b: w16(s16(a) * s16(b)),
    GEQ=lambda a, b: 1 if s16(a) >= s16(b) else 0xFFFF,
    LT =lambda a, b: 1 if s16(a) <  s16(b) else 0xFFFF,
    dtype="int16")

# ---------- header I/O ----------
def load(wl):
    txt = open(f"{SRC}/{wl}/{wl}.h").read()
    def arr(name):
        m = re.search(name + r'\[(\d+)\]\[(\d+)\]\s*=\s*\{(.*?)\};', txt, re.S)
        rs = re.findall(r'\{([^}]*)\}', m.group(3))
        return [[int(x, 0) for x in r.replace('\n', ' ').split(',') if x.strip()] for r in rs]
    d = {n: arr(n) for n in ('RIN3', 'IN0', 'IV0', 'EOUT1', 'EOUT3')}
    d['defs'] = dict(re.findall(r'#define\s+(\w+)\s+(\S+)', txt))
    return txt, d

def decode(RIN3):
    prog = [[None]*8 for _ in range(8)]; dsm = [[0]*8 for _ in range(8)]
    wpre = [[dict() for _ in range(8)] for _ in range(8)]
    for c in range(8):
        byrow = defaultdict(list)
        for v in RIN3[c]:
            if (v >> 25) & 1: byrow[(v >> 21) & 0xF].append(v)
        for r in range(8):
            irf = []; isz = 0
            for v in byrow[r]:
                mode = (v >> 20) & 1; addr = (v >> 16) & 0xF; data = v & 0xFFFF
                if mode == 1 and addr >= 8: irf.append(data)
                elif mode == 1 and addr == 0: dsm[c][r] = data & 0xFF; isz = (data >> 8) & 7
                elif mode == 0: wpre[c][r][addr] = data
            prog[c][r] = irf[:isz + 1]
    return prog, dsm, wpre

# ---------- the certified simulator ----------
def sim(prog, dsm, wpre, west, A, seeds_north=None):
    """west[r]: raw u16 words entering column 0 (row r). Returns dict:
       east[r] list, south[c] list (col c bottom edge)."""
    st = [[dict(regs=[0]*8, full=[0]*8, holdN=[], holdS=[], wq=list(west[r]) if c == 0 else [],
                pc=0, out=[]) for c in range(8)] for r in range(8)]
    for r in range(8):
        for c in range(8):
            for a, d in wpre[c][r].items(): st[r][c]['regs'][a] = d
    if seeds_north:
        for c in range(8): st[0][c]['holdN'] = list(seeds_north[c])
    east = [[] for _ in range(8)]; south = [[] for _ in range(8)]
    progress = True; steps = 0
    while progress and steps < 400000:
        progress = False; steps += 1
        for r in range(8):
            for c in range(8):
                n = st[r][c]; P = prog[c][r]
                if not P: continue
                ins = P[n['pc']]; op = ins & 0xF; dst = (ins >> 4) & 0xF; s1 = (ins >> 8) & 0xF; s2 = (ins >> 12) & 0xF
                binop = op in (0, 1, 2, 8, 9)
                def avail(s):
                    if s == 0xe: return len(n['wq']) > 0
                    if s == 0xc: return len(n['holdN']) > 0
                    if s == 0xd: return len(n['holdS']) > 0
                    if s < 8 and ((dsm[c][r] >> s) & 1): return n['full'][s] == 1
                    return True
                if not all(avail(s) for s in ([s1] + ([s2] if binop else []))): continue
                def rd(s):
                    if s == 0xe: return n['wq'].pop(0)
                    if s == 0xc: return n['holdN'].pop(0)
                    if s == 0xd: return n['holdS'].pop(0)
                    if s < 8 and ((dsm[c][r] >> s) & 1): n['full'][s] = 0
                    return n['regs'][s]
                if   op == 3: res = rd(s1)
                elif op == 2: res = A['MUL'](rd(s1), rd(s2))
                elif op == 0: res = A['ADD'](rd(s1), rd(s2))
                elif op == 1: res = A['SUB'](rd(s1), rd(s2))
                elif op == 8: res = A['GEQ'](rd(s1), rd(s2))
                elif op == 9: res = A['LT'](rd(s1), rd(s2))
                elif 4 <= op < 8:      # router send: deliver value of reg s1 to row s2, addr dst
                    tid = s2; val = n['regs'][s1]
                    tgt = st[tid][c]; tgt['regs'][dst] = val
                    if dst < 8 and ((dsm[c][tid] >> dst) & 1): tgt['full'][dst] = 1
                    n['pc'] = (n['pc'] + 1) % len(P); progress = True; continue
                else: raise Exception(f"op {op:x} unhandled")
                if dst == 0xf:
                    if c < 7: st[r][c + 1]['wq'].append(res)
                    else: east[r].append(res)
                elif dst == 0xd:
                    if r < 7: st[r + 1][c]['holdN'].append(res)
                    else: south[c].append(res)
                elif dst == 0xc:
                    if r > 0: st[r - 1][c]['holdS'].append(res)
                else:
                    n['regs'][dst] = res
                    if dst < 8 and ((dsm[c][r] >> dst) & 1): n['full'][dst] = 1
                n['pc'] = (n['pc'] + 1) % len(P); progress = True
    return east, south

# ---------- helpers ----------
def slots_of(IV0): return {r: [t for t in range(2000) if IV0[r][t]] for r in range(8)}
def fmt(rows): return ',\n'.join('{' + ','.join(('0x%04x' % v if v else '0') for v in r) + '}' for r in rows)
def emit(txt, wl, tag, IN0new, EOUT_new, eout_name, vgmax, dtype, RIN3new=None, note=""):
    out = txt
    for name, new in (('IN0', IN0new), (eout_name, EOUT_new)) + ((('RIN3', RIN3new),) if RIN3new else ()):
        m = re.search(name + r'\[\d+\]\[\d+\]\s*=\s*\{', out); end = out.index('};', m.end())
        out = out[:m.end()] + '\n' + fmt(new) + '\n' + out[end:]
    out = re.sub(r'#define VGMAX \d+', f'#define VGMAX {vgmax}', out)
    out = re.sub(r'#define VECNAME "', f'#define VECNAME "{tag}_', out)
    contract = (f'#define VECTOR_DTYPE_{dtype.upper()} 1\n#define VECTOR_DTYPE "{dtype}"\n'
                f'#define VECTOR_FORMAT_ELASTIC 1\n')
    out = out.replace('#define VM 8', contract + '#define VM 8', 1)
    hdr = (f"// {tag} {wl} vectors ({dtype}) — generated by gen_int16.py from the certified ISA simulator.\n"
           f"// {note}\n// RIN3 program identical to source except weight payloads (mode=0) where noted; slots unchanged.\n")
    path = f"{OUT}/{wl}_{tag}_{dtype}.h"
    open(path, 'w').write(hdr + out)
    return path

def rewrite_weights(RIN3, newW):
    """newW[r][c][addr] = raw payload; rewrite mode=0 packets' data fields in place."""
    R = [row[:] for row in RIN3]
    for c in range(8):
        for i, v in enumerate(R[c]):
            if (v >> 25) & 1 and ((v >> 20) & 1) == 0:
                r = (v >> 21) & 0xF; addr = (v >> 16) & 0xF
                if r in newW and c in newW[r] and addr in newW[r][c]:
                    R[c][i] = (v & ~0xFFFF) | (newW[r][c][addr] & 0xFFFF)
    return R

rng = np.random.default_rng(1234)
report = {}
import time as _T; _t0=_T.time()
def _lap(s): print(f"[{_T.time()-_t0:6.1f}s] {s}", flush=True)

# =====================================================================
# 1) MMM  (south edge, VOUT_IDX 3): out[c][b] = sum_r W[r][c] * act[r][b]
# =====================================================================
txt, A = load('mmm'); prog, dsm, wpre = decode(A['RIN3']); S = slots_of(A['IV0'])
# certify fp16 sim on original batch 0 (all 8 columns)
west0 = [[A['IN0'][r][t] for t in S[r][:2]] for r in range(8)]
e, so = sim(prog, dsm, wpre, west0, FP16)
gold_s = [[v for v in A['EOUT3'][c] if v][:2] for c in range(8)]
assert all(so[c][:2] == gold_s[c] for c in range(8)), "mmm fp16 sim NOT certified"
print("mmm fp16 sim CERTIFIED (8 cols x 2 batches)")
# int16: weights small ints, acts distinct small ints (aperiodic), analytic golden
NB = 20
Wi = {r: {c: {0: w16(int(rng.integers(-7, 8)) or 3)} for c in range(8)} for r in range(8)}
RIN3i = rewrite_weights(A['RIN3'], Wi)
IN0i = [row[:] for row in A['IN0']]
acts = {}
pool = list(range(1, 200)); rng.shuffle(pool); pi = 0
for r in range(8):
    for b in range(NB):
        acts[(r, b)] = pool[pi]; pi += 1
        IN0i[r][S[r][b]] = acts[(r, b)]
progi, dsmi, wprei = decode(RIN3i)
westi = [[IN0i[r][t] for t in S[r][:NB]] for r in range(8)]
e, so = sim(progi, dsmi, wprei, westi, INT16)
# analytic cross-check
for c in range(8):
    for b in range(NB):
        exp = w16(sum(s16(Wi[r][c][0]) * acts[(r, b)] for r in range(8)))
        assert so[c][b] == exp, f"mmm int16 analytic mismatch c{c} b{b}"
EOUT3i = [[0]*2000 for _ in range(8)]
for c in range(8):
    for b in range(NB): EOUT3i[c][b] = so[c][b]
assert min(len(set(EOUT3i[c][:NB])) for c in range(8)) >= 18, "mmm int16 golden not aperiodic"
p = emit(txt, 'mmm', 'INT16', IN0i, EOUT3i, 'EOUT3', NB, 'int16', RIN3i,
         "acts 1..199 distinct ints, weights in [-7,7]; golden = int16 wraparound X@W (sim == analytic).")
report['mmm'] = dict(path=p, outputs_per_lane=[NB]*8, edge='south')
print("mmm int16:", p); _lap("mmm done")

# =====================================================================
# 2) FFT (east edge, VOUT_IDX 1)
# =====================================================================
txt, A = load('fft'); prog, dsm, wpre = decode(A['RIN3']); S = slots_of(A['IV0'])
west0 = [[A['IN0'][r][t] for t in S[r][:2]] for r in range(8)]
e, so = sim(prog, dsm, wpre, west0, FP16)
gold_e = [[v for v in A['EOUT1'][r] if v][:2] for r in range(8)]
assert all(e[r][:2] == gold_e[r] for r in range(8)), "fft fp16 sim NOT certified"
print("fft fp16 sim CERTIFIED (8 rows, batch 0)")
# int16 fft: twiddles ±1 / 0 map to int16 ±1 / 0 exactly (0x8000=-0.0 -> 0); scale = 1
Wf = {r: {c: {} for c in range(8)} for r in range(8)}
for r in range(8):
    for c in range(8):
        for a, d in wpre[c][r].items():
            f = float(u2h(d))
            if abs(f - round(f)) < 1e-6: Wf[r][c][a] = w16(int(round(f)))
            else: Wf[r][c][a] = w16(int(round(f * 4)))    # non-integer twiddle (b9a8=-0.707): x4 fixed-point
RIN3f = rewrite_weights(A['RIN3'], Wf)
IN0f = [row[:] for row in A['IN0']]
pool = [v for v in range(-200, 201) if v != 0]; rng.shuffle(pool); pi = 0   # 400 distinct >= 320 needed
for r in range(8):
    for j in range(2 * NB):
        IN0f[r][S[r][j]] = w16(pool[pi]); pi += 1
progf, dsmf, wpref = decode(RIN3f)
westf = [[IN0f[r][t] for t in S[r][:2 * NB]] for r in range(8)]
e, so = sim(progf, dsmf, wpref, westf, INT16)
assert all(len(e[r]) == 2 * NB for r in range(8)), f"fft int16 east counts {[len(x) for x in e]}"
EOUT1f = [[0]*2000 for _ in range(8)]
for r in range(8):
    for t in range(2 * NB): EOUT1f[r][t] = e[r][t]
dist = [len(set(EOUT1f[r][:2 * NB])) for r in range(8)]
assert min(dist) >= 30, f"fft int16 golden weakly aperiodic {dist}"
p = emit(txt, 'fft', 'INT16', IN0f, EOUT1f, 'EOUT1', 2 * NB, 'int16', RIN3f,
         "inputs distinct ints in [-200,200]; twiddles ±1/0 exact, -0.707 -> -3 (x4 fixed-point); golden = int16 sim.")
report['fft'] = dict(path=p, outputs_per_lane=[2 * NB]*8, edge='east', golden_distinct=dist)
print("fft int16:", p, "distinct/row", dist); _lap("fft done")

# =====================================================================
# 3) CORDIC x4 (east edge): int16 + aperiodic fp16
# =====================================================================
for wl in ('cordic_cr', 'cordic_cv', 'cordic_hr', 'cordic_hv'):
    txt, A = load(wl); prog, dsm, wpre = decode(A['RIN3']); S = slots_of(A['IV0'])
    west0 = [[A['IN0'][r][t] for t in S[r]] for r in range(8)]
    e, so = sim(prog, dsm, wpre, west0, FP16)
    for r in range(8):
        g = [v for v in A['EOUT1'][r] if v]
        assert e[r][:len(g)] == g, f"{wl} fp16 sim NOT certified row {r}"
    print(f"{wl} fp16 sim CERTIFIED  counts {[len(x) for x in e]}"); _lap(wl+" certified")
    # --- aperiodic fp16: distinct inputs per slot, magnitudes near the originals
    IN0a = [row[:] for row in A['IN0']]; used = set()
    for r in range(8):
        for j, t in enumerate(S[r]):
            base = float(u2h(A['IN0'][r][t]))
            for _try in range(1000):
                v = h2u(np.float16(base * float(rng.uniform(0.6, 1.4)) + float(rng.uniform(-0.05, 0.05))))
                if v not in used and v != 0: break
            used.add(v); IN0a[r][t] = v
    westa = [[IN0a[r][t] for t in S[r]] for r in range(8)]
    ea, _ = sim(prog, dsm, wpre, westa, FP16)
    cnt = [len(x) for x in ea]
    E1a = [[0]*2000 for _ in range(8)]
    for r in range(8):
        for t, v in enumerate(ea[r]): E1a[r][t] = v
    dist = [len(set(ea[r])) for r in range(8)]
    p = emit(txt, wl, 'APERIODIC', IN0a, E1a, 'EOUT1', max(cnt), 'fp16', None,
             f"inputs perturbed 0.6-1.4x of originals, all distinct; golden = certified fp16 sim; per-row counts {cnt} (data-dependent).")
    print(f"  {wl} APERIODIC fp16: counts {cnt} distinct {dist} -> {p}")
    # --- int16: inputs as small ints; GEQ/LT integer +-1
    IN0i = [row[:] for row in A['IN0']]
    pooli = [v for v in range(-150, 151) if v != 0]; rng.shuffle(pooli); pi = 0   # 300 distinct >= 240 needed
    for r in range(8):
        for j, t in enumerate(S[r]):
            IN0i[r][t] = w16(pooli[pi]); pi += 1
    westi = [[IN0i[r][t] for t in S[r]] for r in range(8)]
    ei, _ = sim(prog, dsm, wpre, westi, INT16)
    cnti = [len(x) for x in ei]
    E1i = [[0]*2000 for _ in range(8)]
    for r in range(8):
        for t, v in enumerate(ei[r]): E1i[r][t] = v
    disti = [len(set(ei[r])) for r in range(8)]
    p = emit(txt, wl, 'INT16', IN0i, E1i, 'EOUT1', max(cnti), 'int16', None,
             f"inputs distinct ints in [-150,150]; weights (0) unchanged; golden = int16 sim; per-row counts {cnti} (data-dependent).")
    report[wl] = dict(path=p, outputs_per_lane=cnti, edge='east', golden_distinct=disti,
                      aperiodic_fp16=dict(counts=cnt, distinct=dist))
    print(f"  {wl} INT16: counts {cnti} distinct {disti} -> {p}")

json.dump(report, open(f"{OUT}/EXPECTED_COUNTS.json", 'w'), indent=1)
print("\nEXPECTED_COUNTS.json written:", {k: v['outputs_per_lane'] for k, v in report.items()})
