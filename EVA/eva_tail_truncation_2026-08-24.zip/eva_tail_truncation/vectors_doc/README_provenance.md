# EVA int16 + aperiodic-cordic vectors (8x8) — generated, certified, round-trip verified

Generator: `gen_int16.py` (in this folder). Re-runnable: `python3 gen_int16.py` regenerates
everything from `eva_fft_cordic_vectors/<wl>/<wl>.h` (deterministic seed 1234).

## What is in here
| file | dtype | edge | golden values/lane | notes |
|---|---|---|---|---|
| `mmm_INT16_int16.h`        | int16 | south (VOUT_IDX 3) | 40 (all valid slots) | golden = sim **== analytic X@W** (asserted) |
| `fft_INT16_int16.h`        | int16 | east (1) | 40 (20 butterflies x 2 words) | twiddles ±1/0 exact; -0.707 -> -3 (x4 fixed-point) |
| `cordic_{cr,cv,hr,hv}_INT16_int16.h`     | int16 | east (1) | 20 (even rows) / 40 (odd rows) | GEQ/LT -> integer +1 / -1 (e2fix / int16_skid ALU) |
| `cordic_{cr,cv,hr,hv}_APERIODIC_fp16.h`  | fp16  | east (1) | 20 / 40 | replaces the value-periodic fp16 cordic stream stimulus |
| `EXPECTED_COUNTS.json`     | — | — | per-workload, per-lane expected output counts | feed the stamp-count assertion |
| (`../fft_APERIODIC.h`, delivered earlier) | fp16 | east | 40 | rev2, golden-level aperiodicity asserted |

All headers keep the source **program (RIN3), slots, VPC, VL=2000** — only activation payloads,
weight payloads (mmm/fft int16: mode=0 packet data fields), EOUT, VGMAX and VECNAME change.

## How the goldens were produced — and why to trust them
An **ISA-level, data-driven event simulator** of the decoded 8x8 program network (a node grants
its next instruction iff its operands are available; router sends deliver into the target's
register with the dsmask full-flag; systolic sends feed the neighbor's hold). Before generating
anything it was **certified bit-exact against the captured RTL golden** on the original fp16 stimulus:
- mmm: 8 columns x 2 batches ✓ · fft: 8 rows (3 butterfly stages, 2 router-permutation stages,
  passthrough tail) ✓ · cordic cr/cv/hr/hv: all rows incl. the GEQ/LT decisions and the 20/40
  per-row output counts ✓
The int16 arithmetic pack = wraparound two's complement (Allo `int16` ops): ADD/MUL wrap,
**SUB is true subtraction** (the E3 ALU fix — the sign-flip trick is float-only), GEQ/LT
produce **+1 / -1** as integers (matches e2fix `res = 1 / -1` and int16_skid). If a chip's int16
ALU differs from this contract the mismatch is the finding, not the vector.
Every emitted header was **round-trip verified**: re-parsed, re-simulated from its own arrays,
compared against its own EOUT (all 10 OK).

## Contract stamps (compile-time, in every header)
```
#define VECTOR_DTYPE_INT16 1        (or VECTOR_DTYPE_FP16)
#define VECTOR_DTYPE "int16"
#define VECTOR_FORMAT_ELASTIC 1
```
Add to `tb_eva.cpp` next to the machine/prime check:
```
#if defined(INT16) && !defined(VECTOR_DTYPE_INT16)
#error "int16 DUT driven with non-int16 vectors"
#endif
#if !defined(INT16) && defined(VECTOR_DTYPE_INT16)
#error "fp16 DUT driven with int16 vectors"
#endif
```
This closes the 4th stimulus-family bug class (format, prime, mislabeled header, **datatype**).

## Elastic vs skid: same values, different FORMAT
These files are **elastic-format** (dense valid slots, no bubbles, no PRIMECFG). The int16
**values, programs and goldens are machine-independent** — the skid needs the *same content in
credit-format*: slot = timestep, explicit iv=0 bubble slots, PRIMECFG[8][8], VECTOR_MACHINE_ID=1,
the calibrated per-workload prime (mmm 6, fft 3-4, cordic 6). Produce them by pointing the
credit-path builder (`build_golden_cosim` → skid stimulus generator) at these headers as the
**value source**: read IN0 (valid slots in order = activation sequence), the mode-0 payloads of
RIN3 (weights), and EOUT as the golden — the packing into the BSP grid is exactly what that
builder already does for fp16. I did not hand-pack the credit format here on purpose: the
per-machine stimulus contract has bitten this project four times, and the credit layout must
come from the one generator that owns it (that generator can assert VECTOR_MACHINE_ID=1 +
VECTOR_FORMAT_CREDIT on output).

## Expected output counts (stamp-count assertion)
mmm 40x8=320 (south) · fft 40x8=320 (east) · each cordic 20/40 alternating = 240 (east).
Note: with these particular int16/aperiodic inputs the cordic GEQ/LT decisions produced the
**same** 20/40 counts as the fp16 stimulus — but counts are **data-dependent by construction**;
always take them from `EXPECTED_COUNTS.json` (regenerated with the vectors), never from a constant.

## Caveats
- int16 fft twiddle -0.707 has no exact int16; -3 (x4 fixed-point) keeps the *program* identical and
  the golden is whatever the sim computes with it (self-consistent, still a valid correctness oracle
  for the chip; it is not a numerically-meaningful FFT).
- Value ranges were chosen so int16 arithmetic never wraps for mmm/cordic; fft may wrap by design
  (wraparound is part of the contract and the sim models it exactly).
- The simulator is order-agnostic (data-driven, per-flow FIFO order); it computes VALUES, not
  timing — throughput still comes only from rc_mon.
