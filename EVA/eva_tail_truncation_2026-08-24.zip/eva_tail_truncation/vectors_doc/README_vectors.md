# Allo cosim vectors

Per-chip, per-workload stimuli + expected output for driving the Allo EVA chips.

```
Allo/
  tb_eva.cpp              ONE testbench for all 4 chips (flags select prime/datatype)
  <chip>/<workload>/
     <workload>.h                 input + expected-output vector (IN*/IV*/RIN* + EOUT*)
     expected_output_<workload>.txt   golden output, human-readable (active edge, per lane)
```
`<chip>` ∈ {fp16_elastic, int16_elastic, fp16_skid, int16_skid};
`<workload>` ∈ {mmm, fft, cordic_cr, cordic_cv, cordic_hr, cordic_hv}.

The `.h` is the full Allo stimulus: it carries the inputs (`IN0..3`, `IV0..3`, `RIN0..3`),
the golden expected output (`EOUT1` east / `EOUT3` south, picked by `VOUT_IDX`), and — for
skid — `PRIMECFG` + the `VECTOR_PRIME`/`VECTOR_MACHINE_ID` contract fields. All vectors are
**VL=2000**. These `.h` files are the golden `.mem`/activations re-encoded for the array
interface (via build_golden_cosim); their `EOUT` equals the RTL EVA output bit-for-bit.

## Wiring to `tb_eva.cpp`
| chip | cflags |
|---|---|
| fp16_elastic | `-DVECHDR="<wl>.h"` |
| int16_elastic | `-DINT16 -DVECHDR="<wl>.h"` |
| fp16_skid | `-DHAS_PRIME -DDUT_MACHINE_ID=1 -DDUT_PRIME=<p> -DVECHDR="<wl>.h"` |
| int16_skid | `-DHAS_PRIME -DINT16 -DDUT_MACHINE_ID=1 -DDUT_PRIME=<p> -DVECHDR="<wl>.h"` |

`<p>` = the vector's `VECTOR_PRIME` (fft=3, cordic=6, mmm=8; each `.h` states its own).

## Notes
- **int16 chips reuse the fp16-derived skid vectors** and their own int16 elastic strm_vec.
  int16 **correctness reads FAIL by design** (int arithmetic ≠ fp golden) — the valid int16
  result is the rc_mon **throughput**, not the bit-compare.
- **skid fft uses prime=3** (inside the working window 2–5); prime=6 over-drains. cordic=6, mmm=8.
- skid mmm was VL=800 originally and is zero-padded to VL=2000 here so every skid workload
  shares one L (real tokens sit in the first 800 slots; padding is inert).
