# EVA 1 PE Catapult synthesis — final results and open questions
2026-08-24 · Catapult Ultra Synthesis 2024.2/1130128 · Nangate 45 nm (`nangate-45nm_beh`,
typical 1.10 V / 25 °C) · 1 PE, `NSTEP=215`, 2.0 ns clock, `-IO_MODE super`,
`-SPECULATE true`. Post-assignment area, library units. **Pre-layout — no P&R, no power.**

## Results

### Pipelined, node loop at II = 1
| chip | Freq (MHz) | depth | II | REG | FUNC | MUX+LOGIC | Total area |
|---|---|---|---|---|---|---|---|
| fp16 elastic | 253 | 3 | 1 | 34,426 | 9,325 | 29,310 | 73,555 |
| int16 elastic | 250 | 2 | 1 | 34,420 | 7,850 | 26,209 | 68,974 |
| fp16 skid | 487 | 3 | 1 | 90,626 | 23,895 | 38,238 | 153,830 |
| int16 skid | 459 | 2 | 1 | 90,440 | 22,637 | 39,384 | 153,531 |

### Unscheduled baseline
| chip | Freq (MHz) | depth | II | REG | FUNC | MUX+LOGIC | Total area |
|---|---|---|---|---|---|---|---|
| fp16 elastic | 480 | 7 | — | 32,888 | 9,264 | 13,222 | 55,922 |
| int16 elastic | 500 | 8 | — | 32,750 | 7,668 | 11,582 | 52,553 |
| fp16 skid | 471 | 9 | — | 88,594 | 23,572 | 33,379 | 146,690 |
| int16 skid | 535 | 9 | — | 88,429 | 22,143 | 32,054 | 143,771 |

All eight scheduled cleanly (`SCHD-43`, no `SCHD-30`); pipelined runs used
`directive set -PIPELINE_STALL_MODE flush`. Re-run from scratch 2026-08-24 and reproducing
the prior archive to three decimals.

### What changes between them
| | elastic | skid |
|---|---|---|
| clock | **480 → 253 MHz (−47 %)** | 471 → 487 MHz (+3 %) |
| area | 55,922 → 73,555 (+32 %) | 146,690 → 153,830 (+5 %) |
| depth | 7 → 3 | 9 → 3 |

**The two tables rank the machines oppositely.** Unscheduled favours elastic (higher clock,
~⅓ the area); II=1 favours skid. Any claim must name its schedule.

## Where every number comes from
| value | file | location |
|---|---|---|
| Freq | `rtl.rpt` | `Timing Report / Critical Path` → `Max Delay`; freq = 1000/delay |
| **depth** | `cycle.rpt` | Loops table, node `while` row → **`C-Steps`** |
| **II** | `cycle.rpt` | Loops table, node `while` row → **`Init`** (last field) |
| REG / FUNC / MUX / LOGIC | `rtl.rpt` | `Area Scores` → **Post-Assignment (3rd) column** |
| Total area | `rtl.rpt` | `Area Scores` → `Total Area Score` (= DataPath + FSM) |

⚠️ `TOTAL AREA (After Assignment)` is **DataPath only** and excludes the FSM (494 units
elastic, 1,070 skid). `Total Area Score` is the whole design — quote that one.

### Four columns that are NOT the II
| column | what it is |
|---|---|
| `C-Steps` | schedule depth (comparable to Vitis per-iteration latency) |
| `Total Cycles` | manual: *"sum of Total Cycles In and Total Cycles Under"* — loop + nested. Unscheduled 7 + 4×4 = 23 ✓. The manual's worked example covers **rolled loops only**; undefined for a pipelined loop. Do not quote. |
| `Throughput Cycles` (Loop Execution Profile) | static stall estimate (16). **Not measured** — no simulation in these runs (`Current state: schedule`) |
| `II` (Processes table) | process-level — **0 on all 84 process rows** across four runs, both schedules |

`Init` = II confirmed four ways: manual (`PIPELINE_INIT_INTERVAL` = *"the initiation
interval for pipelined loops"*, *"cycles to wait between the start of each loop
iteration"*), `Init` tracking 1/2/4 across three runs, the `SCHD-43` sentence, and the
Gantt chart.

## OPEN QUESTIONS

### 1. Why does elastic's clock collapse at II=1 and skid's not?
Evidence in `evidence/01_frequency_drop_elastic.txt`. Only elastic's pipelined critical
path ends at `drf_full` (the scoreboard) and starts inside a flattened inner loop, running
a not/and/or predicate chain. **Ruled out:** inner-loop flattening alone — skid flattens
*more* inner loops (6 vs 4) without penalty. **Hypothesis (unproven):** elastic's 32
`full()`/`empty()` guards are combinational; at II=1 they collapse into one initiation
window together with the scoreboard update. Skid has **zero** guards — its blocking
Push/Pop become sequential wait-controller state instead.
**Test not yet run:** II=2, or CLK=1.8, to see whether the chain relaxes.

### 2. Is II=1 real throughput? — NO DATA
`Init` is the *scheduled* II over a stall-free schedule. These loops are full of blocking
`Push`/`Pop` (44 `SCHD-46` wait controllers in the elastic node loop); actual rate depends
on mesh backpressure. **No cosim has been run.** Catapult's own static estimate of stalled
throughput is 16 cycles/iteration — not measured, and not the II.

### 3. Elastic drops the last output(s) per lane — UNRESOLVED
On the deep golden vectors elastic emits 39 of 40 per lane (cordic 19/20, 37/40). Values
emitted are bit-exact; only the tail is missing. Not int16-specific, not caused by the
Aug-19 revision, not budget (5× tested), not collector starvation. Ablations exonerated
divergence 1 (consuming router read), 2a (`retire_ok`), and forwarding; the router-accept
`ig_v` park (2b) is the sole surviving suspect. Full package:
`eva_tail_truncation_2026-08-24.zip`. **Correctness only — synthesis numbers unaffected.**

### 4. No 8×8, no RTL verification on the current emitter
All results here are 1 PE csyn. The Aug-19 v3.0/elastic 8×8 cosims were lost when
`/scratch` was reused. **No chip is currently RTL-verified at 8×8 on the current emitter.**

### 5. rbuf2 is a no-op in this flow (resolved, recorded)
The Vitis `array_partition variable=rbuf complete dim=2` injection has **zero** effect
here — byte-identical to plain skid in both schedules, confirmed three times. Catapult
infers no memories at 1 PE (`MEM/ROM = 0`), so `rbuf` is already registers. Catapult has
no `array_partition` directive; the nearest lever is `MAP_TO_MODULE`. Do not present the
rbuf2 rows as a distinct design; their value is the P&R data at
`verification/{fp16,int16}_skid/pnr_rbuf2_1x1/`.

## ⚠️ Reproducing a run: Catapult MUST run from a build subdir
`allo/backend/hls.py:1330` runs Catapult with cwd = `<project>/build`. **With cwd = the
source directory, the MatchLib Connections In/Out ports degrade to raw `sc_signal`s
(`CIN-124`) → `iomode=fixed` → `SCHD-30`, and the design will not schedule.** Measured: 208
`CIN-124` from the source dir vs 80 from the build subdir; the first `HC-8` becomes
`node_0_0::run -inline` instead of `solution design set top -top`, and only 1 of 11
`CIN-203` pragmas is seen. Cost two hours tonight.

    cd <project>/build && catapult -shell -f <project>/run.tcl    # correct

The batch flow writes no `.ccs`, so a finished project cannot be reopened in the GUI —
re-run with `catapult -file ../run_gui.tcl` (tcl with trailing `exit` removed) from the
build subdir, then `view schedule`.

## Contents
    chips/     4 canonical Aug-19 sources + rbuf2 injector + CHECKSUMS.txt
    reports/   per chip × schedule: SUMMARY, area_scores, critical_path, node_loop,
               SCHD-43, run.tcl
    evidence/  01 — the frequency-drop investigation
Full reports (rtl.rpt, cycle.rpt, RTL, logs) live at
`/work/shared/users/zsm9/final_verification/<chip>/{pipelined,unscheduled}/`.
