# Removing the occupancy sideband: `full()`/`empty()` guards -> `try_put`/`try_get`
2026-08-25 · fp16_elastic, 1 PE · Catapult Ultra 2024.2 · Nangate 45 nm · **future-work
result, NOT a thesis number** (a new design point three days out, not a correction).

## Result
| fp16_elastic, II=1 | guarded (current) | **try_\* variant** | Δ |
|---|---|---|---|
| max delay | 3.9460 ns | **2.3539 ns** | |
| frequency | 253 MHz | **425 MHz** | **+68 %** |
| total area | 73,555 | **58,360** | **−20.7 %** |
| `AlloFifoC` instances | 16 | **0** | sideband gone |
| plain `Connections::Fifo` | 0 | **16** | |
| `_empty_sig` / `_full_sig` | 96 | **0** | |
| schedule | SCHD-43 II=1 | SCHD-43 II=1, no SCHD-30 | |

For scale: the *unscheduled guarded* design is 2.0831 ns / 480 MHz / 55,922. The try_\*
variant at II=1 lands near that on both axes **while pipelined**.

## Verification
| gate | result |
|---|---|
| sideband eliminated | ✅ (table above) |
| schedule clean, no multi-drive | ✅ `write#N` histogram empty |
| csim 1×1 / 2×2 | ✅ bit-exact vs numpy |
| **cosim 1×1 / 2×2** | ✅ **bit-exact RTL, 8 output arrays** |

The 2×2 cosim is the one that mattered: removing a cycle of guard conservatism inside a
**cyclic** router graph is where a deadlock or ordering change would hide from csim. It
did not materialise.

⚠️ **Weak oracle.** The stimulus is a synthetic 3-batch MMM vs numpy — not the golden EVA
vectors (six real programs), which are **8×8-only** and cannot drive a 1×1/2×2 mesh. It is
also far too shallow to see the tail-truncation bug (needs ~40 outputs/lane).
⚠️ Part of the −20.7 % is **removed plumbing** (96 signals + 16 sideband processes), not
better logic. Separate the two before quoting it as a design win.

## The change (chip source only — no emitter change)
32 guard sites, one mechanical pattern. `chips/guards_to_nb.diff` has it in full;
`scripts/convert_guards_to_nb.py` reproduces it.

```python
# producer, before                        # after
if oh_v[0] == 1 and CH.full() == 0:       if oh_v[0] == 1:
    CH.put(oh_p[0]); oh_v[0] = 0              _ok = CH.try_put(oh_p[0])
                                              if _ok == 1: oh_v[0] = 0

# consumer, before                        # after
if ig_v[0] == 0 and CH.empty() == 0:      if ig_v[0] == 0:
    ig_p[0] = CH.get(); ig_v[0] = 1           _g, _k = CH.try_get()
                                              if _k == 1: ig_p[0] = _g; ig_v[0] = 1
```

**Data-driven firing is preserved.** The outer work-gating condition (`if oh_v==1`,
`if ig_v==0`, `if hold_cnt<2`) is untouched; only the channel-readiness QUERY is replaced
by the attempt's own return value. This is *not* v16's always-fire: v16 failed with six NB
sites driving one port (`vld.write#6`); this source is one site per port per region
(precondition checked before converting, and re-checked by the script).

Note: `try_put`'s result takes no type annotation in the chip DSL (`_ok = ...`, not
`_ok: uint1 = ...`).

## Why the sideband exists at all
`Connections::Fifo` has **no** occupancy query — its public interface is `clk`, `rst`,
`enq`, `deq`; `full` is protected. `AlloFifoC` subclasses it purely to surface
`empty_o`/`full_o`, and the emitter instantiates it only when a consumer polls
(`streamValueQueried()` in EmitSystemC.cpp). With `try_*` there are no polls, so every
stream drops to the vendor FIFO. **skid already sits at that end** (0 AlloFifoC, 32 plain
Fifo) — which is why skid's clock is unaffected by pipelining.

## A hypothesis this REPLACES (falsified, see the other packet)
The earlier theory was that the combinational occupancy sideband set elastic's critical
path, fixable by registering the flags. That was **implemented and falsified**: an
`ALLO_FIFO_STATUS=registered` emitter knob left the critical path unchanged (int16, II=1:
4.0056 -> 3.9589 ns, same launch register, same endpoint). `reg(tail)` is the vendor
FIFO's own pointer driving its DATA path, not the sideband. The knob was reverted.
Removing the query entirely is a different mechanism and it works.

## ⭐ WHY THIS SHOULD BE RUN ON THE 8×8 GOLDEN VECTORS NEXT
The open tail-truncation bug (elastic emits 39 of 40 outputs/lane; see
`eva_tail_truncation_2026-08-24.zip`) had exactly one surviving suspect after ablation:
the **router-accept `ig_v` park** — `accept = 0` when the destination is full, with no
else, so the packet sits and jams the chain. This conversion **rewrites that path**:
`empty()`-then-`get()` becomes an atomic `try_get()`, removing the query-then-act window
where a packet parks against a stale flag.

So the 8×8 golden-vector run answers two questions at once: is try_\* correct on real EVA
programs, and does it touch the open defect. It is also the ONLY stimulus that can see the
bug. **Not yet run.**

## Contents
    chips/     both sources + CHECKSUMS.txt + guards_to_nb.diff (the full change)
    scripts/   convert_guards_to_nb.py (reproduces it; checks the multi-drive precondition)
    reports/   guarded/ and nb/: area_scores, critical_path, node_loop
