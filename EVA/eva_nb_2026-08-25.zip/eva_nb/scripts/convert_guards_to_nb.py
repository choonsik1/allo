#!/usr/bin/env python3
"""Rewrite an elastic chip's full()/empty() guards as try_put/try_get (PushNB/PopNB).

    python3 scripts/convert_guards_to_nb.py <in.py> <out.py>

WHY: the guards are the only reason the emitter instantiates AlloFifoC (see
streamValueQueried() in EmitSystemC.cpp) -- the occupancy sideband exists solely to
answer empty()/full(). With try_* the attempt returns its own success, so every stream
drops to a plain Connections::Fifo and the sideband (ports + signals + status process)
disappears entirely.

Data-driven firing is PRESERVED: the outer work-gating condition (`if oh_v==1`,
`if ig_v==0`, `if hold_cnt<2`) is untouched. Only the channel-readiness QUERY is
replaced by the attempt's return value.

PRECONDITION -- CHECK BEFORE TRUSTING THE OUTPUT: at most one NB site per port per
region. v16 failed to schedule (SCHD-30) with six NB sites driving one port
(`vld.write#6`); the guarded elastic source is one-site-per-port, so a mechanical
conversion is safe. Verify with the counter this script prints.
"""
import re, sys

CH = r"([A-Za-z_]\w*\[[^\]]*\])"

def convert(s):
    c = [0]; n = {"put": 0, "get": 0}
    def nxt():
        c[0] += 1; return c[0]
    # producer: `if COND and CH.full() == 0:\n  CH.put(X); TAIL`
    def p_inline(m):
        ind, cond, ch, i2, ch2, arg, tail = m.groups()
        if ch != ch2: return m.group(0)
        t = nxt(); n["put"] += 1
        return (f"{ind}if {cond}:\n{i2}_ok{t} = {ch2}.try_put({arg})\n"
                f"{i2}if _ok{t} == 1: {tail}\n")
    s = re.sub(rf"( *)if (.+?) and {CH}\.full\(\) == 0:\n( *){CH}\.put\((.+?)\); (.+?)\n", p_inline, s)
    # producer, driver form: `elif CH.full() == 0:\n  CH.put(X)\n  STMT`
    def p_elif(m):
        ind, ch, i2, ch2, arg, i3, stmt = m.groups()
        if ch != ch2: return m.group(0)
        t = nxt(); n["put"] += 1
        return (f"{ind}else:\n{i2}_ok{t} = {ch2}.try_put({arg})\n"
                f"{i2}if _ok{t} == 1:\n{i2}    {stmt}\n")
    s = re.sub(rf"( *)elif {CH}\.full\(\) == 0:\n( *){CH}\.put\((.+?)\)\n( *)(.+?)\n", p_elif, s)
    def p_elif2(m):
        ind, ch, i2, ch2, arg, tail = m.groups()
        if ch != ch2: return m.group(0)
        t = nxt(); n["put"] += 1
        return (f"{ind}else:\n{i2}_ok{t} = {ch2}.try_put({arg})\n"
                f"{i2}if _ok{t} == 1: {tail}\n")
    s = re.sub(rf"( *)elif {CH}\.full\(\) == 0:\n( *){CH}\.put\((.+?)\); (.+?)\n", p_elif2, s)
    # consumer, inline: `if COND and CH.empty() == 0:\n  DST = CH.get(); TAIL`
    def g_inline(m):
        ind, cond, ch, i2, dst, ch2, tail = m.groups()
        if ch != ch2: return m.group(0)
        t = nxt(); n["get"] += 1
        return (f"{ind}if {cond}:\n{i2}_g{t}, _k{t} = {ch2}.try_get()\n"
                f"{i2}if _k{t} == 1: {dst} = _g{t}; {tail}\n")
    s = re.sub(rf"( *)if (.+?) and {CH}\.empty\(\) == 0:\n( *)(\S+?) = {CH}\.get\(\); (.+?)\n", g_inline, s)
    # consumer, annotated: `if COND and CH.empty() == 0:\n  NM: T = CH.get()\n  STMT`
    def g_ann(m):
        ind, cond, ch, i2, nm, ty, ch2, stmt = m.groups()
        if ch != ch2: return m.group(0)
        t = nxt(); n["get"] += 1
        return (f"{ind}if {cond}:\n{i2}_g{t}, _k{t} = {ch2}.try_get()\n"
                f"{i2}if _k{t} == 1:\n{i2}    {nm}: {ty} = _g{t}\n{i2}    {stmt}\n")
    s = re.sub(rf"( *)if (.+?) and {CH}\.empty\(\) == 0:\n( *)(\w+): (\w+) = {CH}\.get\(\)\n *(.+?)\n", g_ann, s)
    # collector: `if CH.empty() == 0:\n  NM: T = CH.get()\n` (body left in place)
    def g_col(m):
        ind, ch, i2, nm, ty, ch2 = m.groups()
        if ch != ch2: return m.group(0)
        t = nxt(); n["get"] += 1
        return (f"{ind}_g{t}, _k{t} = {ch2}.try_get()\n{ind}if _k{t} == 1:\n"
                f"{i2}{nm}: {ty} = _g{t}\n")
    s = re.sub(rf"( *)if {CH}\.empty\(\) == 0:\n( *)(\w+): (\w+) = {CH}\.get\(\)\n", g_col, s)
    return s, n

if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    s = open(src).read()
    out, n = convert(s)
    left = len(re.findall(r"\.(full|empty)\(\)", out))
    open(dst, "w").write(out)
    import ast; ast.parse(out)                      # syntax gate
    print(f"  converted : {n['put']} put-guards, {n['get']} get-guards")
    print(f"  remaining full()/empty() : {left}   {'OK' if left == 0 else '*** NOT ZERO -- sideband will persist ***'}")
    # PRECONDITION: at most ONE NB site per port PER REGION (a def ... block).
    # Counting by channel name across the whole file is wrong -- a name legitimately
    # appears once per region and once per array index. v16's SCHD-30 came from
    # multiple sites inside ONE region driving one port (`vld.write#6`).
    import collections
    regions = re.split(r"\n(?= *def \w+\()", out)
    worst = {}
    for r in regions:
        m = re.match(r"\s*def (\w+)", r)
        if not m: continue
        h = collections.Counter(re.findall(r"([A-Za-z_]\w*\[[^\]]*\])\.try_(?:put|get)\(", r))
        for port, k in h.items():
            if k > 1: worst[f"{m.group(1)}:{port}"] = k
    if worst:
        print(f"  *** MULTI-DRIVE within a region: {worst} -- will hit SCHD-30 ***")
    else:
        print("  precondition OK : <=1 NB site per port per region")
